<?php
session_start();

$bdd = new PDO ('mysql:host=localhost;dbname=projet','root','');

if (  (! empty($_POST['email']))  && (! empty($_POST['contact'])) ) {




$Pdostat=$bdd->prepare('SELECT * FROM admin WHERE email = ? and contact= ?');

$Pdostat->execute(array($_POST['email'],$_POST['contact']));

$test = $Pdostat-> fetch();

$_SESSION['nom'] = $test['nom'] ;

echo $_SESSION['nom'] ;

$insertsoK = $Pdostat->rowCount();






if ( $insertsoK > 0)
{
echo '<script>  </script> '. header("location:index.php");
} 
else
{
echo '<script>  </script> '. header("location:connect.php");;
}

}
else
{
 echo '<script>  </script> '. header("location:connect.php");

}
?>