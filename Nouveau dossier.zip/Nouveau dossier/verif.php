
<?php

$bdd = new PDO ('mysql:host=localhost;dbname=projet','root','');

if ( (! empty($_POST['email']))  && (! empty($_POST['contact'])) && (! empty($_POST['lieu'])) && (! empty($_POST['name'])) ) 
{




$Pdostat=$bdd->prepare('INSERT INTO admin (nom,email,contact,position) VALUES (?,?,?,?)');

$insertsoK = $Pdostat->execute(array($_POST['name'],$_POST['email'],$_POST['contact'],$_POST['lieu']));





if ($insertsoK)
{
echo '<script>  </script> '. header("location:redirect.php");
} 
else
{
echo	"inscription non reuissi reesayer svp ".'<a href="form.php" > retour </a> ';
}

}
else
{
 echo  '<script>  </script> '. header("location:form.php"); ;
}
?>