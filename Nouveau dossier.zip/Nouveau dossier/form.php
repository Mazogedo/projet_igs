<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="fontawesome-free-5.15.2-web/css/all.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>



<form method="post" action="verif.php">

    <h1 align="center"> Veuillez vous inscrire svp </h1>
    <br>
<div style="background-color:aqua;" align="center" class="container">
  
    <div class="row">
      <div class="col">
      <i class="fas fa-user"></i>
        <input type="text" class="form-control"  placeholder="votre nom" name="name">
      </div>
      <div class="col">
      <i class="fas fa-phone-square-alt"></i>
        <input type="text" class="form-control" placeholder="votre contact" name="contact">
      </div>
    </div>
  <br>
    <div class="form-row">
      <div class="col">
      <i class="fas fa-at"></i>
        <input type="text" class="form-control"  placeholder="Enter email" name="email">
      </div>
      <div class="col">
      <i class="fas fa-map-marked-alt"></i>
        <input type="text" class="form-control" placeholder="lieu habitation" name="lieu">
      </div>
    </div>
            <br>
    <button type="submit" class="btn btn-primary"> INSCRIRE </button> <button type="reset" class="btn btn-danger">EFFACER</button> 
            
</form>
</div>

</body>
</html>