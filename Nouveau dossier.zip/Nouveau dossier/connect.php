<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="fontawesome-free-5.15.2-web/css/all.css">
</head>
<body>

    <h1 align="center"> Entrer votre Email & Contact pour vous connecter </h1>
<br>

<div  style="background-color:aqua;" class="container">

  <form method="post" action="insert.php" class="was-validated">
    <div class="form-group">
      <label for="uname"> <i class="fas fa-phone-square-alt"></i> </label>
      <input type="text" class="form-control" id="uname" placeholder="votre contact" name="contact" required>
      <div class="valid-feedback">Valid.</div>
      <div class="invalid-feedback"> </div>
    </div>
    <div class="form-group">
      <label for="pwd"> <i class="fas fa-at"></i> </label>
      <input type="email" class="form-control" id="pwd" placeholder="votre email" name="email" required>
      <div class="valid-feedback">Valid.</div>
      <div class="invalid-feedback"> </div>
    </div>
    <div class="form-group form-check">
      <label class="form-check-label">
        <input class="form-check-input" type="checkbox" name="remember" required> 
        <div class="valid-feedback">Valid.</div>
        <div class="invalid-feedback"> Enregistrer le mot de passe  </div>
      </label>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
</div>

</body>
</html>