<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <link href="style.css" type="text/css" rel="stylesheet" >
</head>
<body>

         
<nav id="tites" class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container">
    <a class="navbar-brand" href="#">
      <img src="zer.jpg" alt="Logo" style="width:30px;" class="rounded-pill">
      <p>  <?php echo $_SESSION['nom'] ?> </p>
    </a>
  </div>
</nav>

<h2 style="font-size:xx-large;" align="center">   Bienvenue voici vos coordonnes      </h2>

<?php 
$bdd = new PDO ('mysql:host=localhost;dbname=projet','root','');


$Pdostat=$bdd->prepare('SELECT * FROM admin WHERE nom = ?');

$Pdostat->execute(array( $_SESSION['nom']));

$test = $Pdostat-> fetch();



?>
<br>
<div style="border:1px solid silver;" class="container">
        <div align="center" class="row">
                <div class="col-sm-2">   </div>
                <div class="col-sm-2"> NOM </div>
                <div class="col-sm-2"> EMAIL  </div>
                <div class="col-sm-2"> CONTACT </div>
                <div class="col-sm-2"> LIEU HABITATION  </div>
                <div class="col-sm-2">   </div>
        </div>
        <div style="background-color:aqua;" align="center" class="row">
                <div class="col-sm-2">   </div>
                <div class="col-sm-2"> <?php echo $test['nom']   ?> </div>
                <div class="col-sm-2"> <?php echo $test['email']   ?>   </div>
                <div class="col-sm-2"> <?php echo $test['contact']   ?>   </div>
                <div class="col-sm-2">  <?php echo $test['position']   ?>  </div>
                <div class="col-sm-2">   </div>
        </div>
</div>
</body>
</html>
