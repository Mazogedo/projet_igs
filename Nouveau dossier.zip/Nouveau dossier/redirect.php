
<table bgcolor="silver" align="center" cellspacing="100" cellpadding="100" >
    <tr>
        <td> <a href="form.php"> <img src="retour.jpg" width="100"  height="100"> </a> <br>  cliquer pour retour </td>
        <td>  <a href="connect.php"> <img src="clic.jpg" width="100" height="100" > </a> <br> cliquer pour vous connecter </td>
    </tr>